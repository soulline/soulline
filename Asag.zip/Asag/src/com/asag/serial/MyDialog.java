package com.asag.serial;

import android.app.Dialog;
import android.content.Context;

public class MyDialog extends Dialog {
	public MyDialog(Context context) {
		super(context);
		setContentView(R.layout.parasetting);
	}
}
