package com.asag.serial.mode;

public class RightDataEntry extends BaseEntry {

	public String co2 = "";
	
	public String wendu = "";
	
	public String shidu = "";
	
	public String number = "";
	
	public String ph3data = "";
	
	public String o2 = "";
}
