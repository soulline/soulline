package com.asag.serial.mode;

public class PointRecord extends BaseEntry {

	public boolean isCheck = false;
	
	public String date = "";
	
	public String way0State = "";
	
	public String way1State = "";
	
	public String way2State = "";
	
	public String way3State = "";
	
	public String way4State = "";
	
	public String way5State = "";
	
	public String way6State = "";
	
	public String way7State = "";
	
	public String way8State = "";
	
	public String way9State = "";
	
	public String way10State = "";
	
	public String way11State = "";
	
	public String way12State = "";
	
	public String way13State = "";
	
	public String way14State = "";
	
	public String way15State = "";
}
