package com.asag.serial.mode;

import java.io.Serializable;

public class BaseEntry implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 11000145556L;

}
