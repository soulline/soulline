package com.asag.serial.mode;

import java.util.ArrayList;

public class CheckDetailItem extends BaseEntry {

	public int id = -1;
	
	public String canghao = "";
	
	public String liangzhong = "";
	
	public String shuliang = "";
	
	public String shuifen = "";
	
	public String chandi = "";
	
	public String rukuDate = "";
	
	public String checkDate = "";
	
	public String checkType = "";
	
	public String saveTime = "";
	
	public String chuliangState = "";
	
	public String shuifenState = "";
	
	public ArrayList<PointItemRecord> pointList = new ArrayList<PointItemRecord>();
	
}
