package com.asag.serial.mode;

public class InputEntry extends BaseEntry {

	public int type = 0;
	
	public String value = "";
	
}
