package com.asag.serial.mode;

public class PointInfo extends BaseEntry {

	public String way = "";
	
	public String xpoint = "";
	
	public String ypoint = "";
	
	public String zpoint = "";
}
