package com.asag.serial.mode;

public class CutDownEntry extends BaseEntry {

	public int type = 0;
	
	public int time = 0;
}
