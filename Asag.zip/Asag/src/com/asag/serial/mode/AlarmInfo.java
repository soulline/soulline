package com.asag.serial.mode;

public class AlarmInfo extends BaseEntry {
	public int checkN = 0;
	public int paikongN = 0;
	public long firstTimeN = 0L;
	public int minuteN = 0;
}
