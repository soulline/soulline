package com.asag.serial.mode;

public class TimeSetEntry extends BaseEntry {

	public int paikongTime = 0;
	
	public int checkTime = 0;
}
