package com.asag.serial.mode;

public class SpinnerItem extends BaseEntry {

	public String name = "";
	
	public String code = "";
}
