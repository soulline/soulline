package com.asag.serial.fragment;

public interface BaseFragmentListener {

	public void onCallBack(Object object);

}
