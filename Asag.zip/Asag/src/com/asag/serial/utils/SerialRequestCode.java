package com.asag.serial.utils;

public class SerialRequestCode {

	public static final int REQUEST_SET_DATA = 10411;
}
